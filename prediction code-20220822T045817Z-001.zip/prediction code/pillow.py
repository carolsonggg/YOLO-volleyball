from PIL import Image
from PIL.ExifTags import TAGS

imagename = "pic.jpg"
image = Image.open(imagename)

info_dict = {
    "Filename": image.filename,
    "Image Size": image.size,
    "Image Height": image.height,
    "Image Width": image.width,
    "Image Format": image.format,
    "Image Mode": image.mode,
    "Image is Animated": getattr(image, "is_animated", False),
    "Frames in Image": getattr(image, "n_frames", 1)
}

for label,value in info_dict.items():
    print(f"{label:25}: {value}")

exifdata = image.getexif()

'''for tag_id in exifdata:
    tag = TAGS.get(tag_id, tag_id)
    data = exifdata.get(tag_id)
    print(tag, ": ", data)'''

info = image._getexif()
ret = {TAGS.get(tag, tag): value for tag, value in info.items()}

for key in ret:
    print(key, ": ", ret[key])
    
